#ifndef _WINDOW_HEAD_
#define _WINDOW_HEAD_

#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <stdint.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#endif
