

#include "C8051F340.h"
#include "mytypedef.h"

INT8U SPI_ExchangeByte( INT8U Byte );